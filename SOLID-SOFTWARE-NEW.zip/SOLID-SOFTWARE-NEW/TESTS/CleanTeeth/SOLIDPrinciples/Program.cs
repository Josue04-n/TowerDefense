﻿using CleanTeeth.Domain.Entities;
using CleanTeeth.Domain.ValueObjects;
using SOLIDPrinciples.Application.Interfaces;
using SOLIDPrinciples.Application.Services;
using SOLIDPrinciples.Infrastructure.Notifications.Adapters;
using SOLIDPrinciples.Infrastructure.Notifications.Emails;
using SOLIDPrinciples.Infrastructure.Notifications.Messaging;
using SOLIDPrinciples.Infrastructure.Notifications.Sms;
using SOLIDPrinciples.Infrastructure.Persistence;

namespace SOLIDPrinciples;

internal class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("╔═══════════════════════════════════════════════════════════════════════════════════╗");
        Console.WriteLine("║  PRINCIPIOS SOLID                                                                 ║");
        Console.WriteLine("║  PASO 5: LISKOV SUBSTITUTION PRINCIPLE (LSP) - PRINCIPIO DE SUSTITUCIÓN DE LISKOV ║");
        Console.WriteLine("║  Sistema CleanTeeth - REFACTORIZADO                                               ║");
        Console.WriteLine("╚═══════════════════════════════════════════════════════════════════════════════════╝\n");

        // ── Crear y agendar la cita ──
        Email patientEmail = new Email("johndoe@email.com");
        Patient patient = new Patient("John Josue", patientEmail);

        Email dentistEmail = new Email("dentist@gmail.com");
        Dentist dentist = new Dentist("Dr. Smith", dentistEmail);

        DentalOffice dentalOffice = new DentalOffice("Consultorio CleanTeeth");

        TimeInterval timeInterval = new TimeInterval(
            DateTime.UtcNow.AddHours(1),
            DateTime.UtcNow.AddHours(2)
        );

        Appointment appointment = new Appointment(
            patient.Id, dentist.Id, dentalOffice.Id, timeInterval
        );

        IAppointmentRepository repository = new DataBaseAppointmentRepository();

        List<INotifactionService> notifactions = new List<INotifactionService>();
        notifactions.Add(new EmailNotificationService(new SmptpEmailService()));

        AppointmentService appointmentService = new AppointmentService(repository, notifactions);
        appointmentService.Schedule(appointment, patient);

        // ── Sumar al archivo compartido ──
        CitaCounterService2.GetInstance().SumarUno();

        int conteoAhora = CitaCounterService2.GetInstance().ObtenerCantidad();

        Console.WriteLine($"Total acumulado en archivo: {conteoAhora}");

        // ── Menú de opciones ──
        Console.WriteLine("Opciones:");
        Console.WriteLine("  [R] Resetear contador");
        Console.WriteLine("  [ENTER] Salir");

        string? input = Console.ReadLine();
        if (input?.ToUpper() == "R")
        {
            CitaCounterService2.GetInstance().Resetear();
            Console.WriteLine("Contador reseteado a 0 ✓");
            Console.ReadLine();
        }
    }
}