﻿namespace SOLIDPrinciples.Application.Services;

public sealed class CitaCounterService2
{
    private static CitaCounterService2? _instance;
    private static readonly object _lock = new object();

    // Archivo compartido entre todos los .exe
    private readonly string _filePath = "contador_citas.txt";

    private CitaCounterService2() { }

    public static CitaCounterService2 GetInstance()
    {
        if (_instance == null)
        {
            lock (_lock)
            {
                if (_instance == null)
                    _instance = new CitaCounterService2();
            }
        }
        return _instance;
    }

    public void SumarUno()
    {
        lock (_lock)
        {
            int actual = ObtenerCantidad();
            File.WriteAllText(_filePath, (actual + 1).ToString());
        }
    }

    public int ObtenerCantidad()
    {
        if (!File.Exists(_filePath)) return 0;
        string contenido = File.ReadAllText(_filePath).Trim();
        return int.TryParse(contenido, out int cantidad) ? cantidad : 0;
    }

    // Para resetear en demo/pruebas
    public void Resetear()
    {
        File.WriteAllText(_filePath, "0");
    }
}
