﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SOLIDPrinciples.Application.Services;

public sealed class CitaCounterService
{
    // 1. Instancia única estática
    private static CitaCounterService? _instance;

    // 2. Lock para thread-safety
    private static readonly object _lock = new object();

    // 3. El contador
    private int _cantidad = 0;

    // 4. Constructor PRIVADO (nadie puede hacer "new CitaCounterService()")
    private CitaCounterService() { }

    // 5. Método para obtener la única instancia (Double-Check Locking)
    public static CitaCounterService GetInstance()
    {
        if (_instance == null)
        {
            lock (_lock)
            {
                if (_instance == null)
                {
                    _instance = new CitaCounterService();
                    Console.WriteLine("   [Singleton] ¡Instancia CREADA por primera vez!");
                }
            }
        }
        return _instance;
    }

    // 6. Sumar con lock para que los hilos no se pisen
    public void SumarUno()
    {
        lock (_lock)
        {
            _cantidad++;
        }
    }

    public int ObtenerCantidad() => _cantidad;
}

